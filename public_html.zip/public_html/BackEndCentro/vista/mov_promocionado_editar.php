<?php
@session_start();

// Importar funcionalidades
require_once("../config/global.php");  
require_once(DEF_PATH_ADMIN);
require_once(DEF_PATH_HTML_PROMOCIONADO);

// Controlar sesión activa
if(!isset($_SESSION['logged_in']) && !$_SESSION['logged_in']){
	header('Location: '+ DEF_URL_LOGIN);
}

// Instanciar clase
$crud = new crud();

// Definir estructura
$array_campo_pk	= array('V_COD_TABLA');
$array_valor_pk	= array(DEF_TABLA_PROMOCION);

// Recuperar registro
$array_opcion = $crud->fila_recuperar(DEF_TABLA_MENU_OPC, $array_campo_pk, $array_valor_pk);

// Almacena ID
$id_codigo_padre = $_GET["id_codigo_padre"];
$id = $_GET["id_codigo"];

// Capturar Variable GET Msg Rpta
if (isset($_GET['id_msgRpta'])) {
	$ls_msgRpta = $_GET["id_msgRpta"];
}else{
	$ls_msgRpta = '';
}

// Invocar Contenido
f_admin_carga();
f_admin_cabecera();
f_admin_cuerpo_izda($array_opcion['N_COD_NIVEL'], $array_opcion['N_ORDEN']);

// Si existe ID	
if ($id){
	
	// Instanciar clase
	$crud = new crud();
	
	// Recuperar arreglo
	$array_campo_pk	= array('N_COD_PROMOCION', 'N_COD_ESTUDIANTE');
	$array_valor_pk	= array($id_codigo_padre, $id);
	
	// Invocar fila
	$array = $crud->fila_recuperar(DEF_TABLA_PROMOCIONPROG, $array_campo_pk, $array_valor_pk);
	
	// Abrir formulario
	f_formulario($array_opcion['V_ETIQUETA'], $array_opcion['V_ICONO'], $ls_msgRpta, $array, NULL);
	
}
else
{
	f_listado($array_opcion['V_ETIQUETA'], $array_opcion['V_ICONO'], $ls_msgRpta);
}
	
f_admin_pie();
f_admin_script('0', 'asc');

?>