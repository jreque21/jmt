<?php
@session_start();

// Importar funcionalidades
require_once("../config/global.php");  
require_once(DEF_PATH_ADMIN);

// Instanciar clase de la B.D
$bd = new baseDatos();
$crud = new crud();

// Validar ingreso de datos
if(isset($_POST) && !empty($_POST)){
	
	//$li_codigo = $_GET["id_codigo"];

	// Almacenar contenido con escape
	$ls_codigo		= $bd->bd_escapeCadena($_POST['id_codigo']);
	$ls_des_larga	= $bd->bd_escapeCadena($_POST['id_des_larga']);
	$ls_des_corta	= $bd->bd_escapeCadena($_POST['id_des_corta']);
	$ls_cod_tipouser= $bd->bd_escapeCadena($_POST['id_tipo_user']);
	$ls_flag_estado	= $bd->bd_escapeCadena($_POST['id_flag_estado']);

	// Gestionar estado
	if ($ls_flag_estado != '1') {
		$ls_flag_estado = '0';
	}
	
	// Obtener datos iniciales
	$ldt_fecha_actualizacion = date('Y-m-d h:i:s');
			
	// ======================================= CRUD ACTUALIZAR =========================================== //
	
	// Definir estructura
	$array_campo_pk	= array('V_COD_ROL');
	$array_valor_pk	= array($ls_codigo);
	$array_campo	= array('V_DES_LARGA', 'V_DES_CORTA', 'V_COD_TIPOUSER', 'V_FLAG_ESTADO', 'V_AUD_USR_MOD', 'D_AUD_FEC_MOD');
	$array_valor	= array($ls_des_larga, $ls_des_corta, $ls_cod_tipouser, $ls_flag_estado, $_SESSION['usr_conectado'], $ldt_fecha_actualizacion);
	
	// Invocar Actualización
	$lb_result = $crud->fila_actualizar(DEF_TABLA_ROL, $array_campo_pk, $array_valor_pk, $array_campo, $array_valor);
	
	// ===================================== FIN CRUD ACTUALIZAR ========================================= //
	
	// Redireccionar
	if($lb_result == true) {
		header("Location: ../vista/mae_rol_lista.php");
	}
	else {
		header("Location: ../vista/mae_rol_editar.php?id_codigo=".$_POST["id_codigo"]);
	}
	
}

?>
